
# ITG FACTORY v2 - Complete App Factory - Deploy & Market Today

## What you have now: Build ANY AI or App system for clients

This is not just workflow automation anymore. It's an App Factory.

### 1-Click Deploy to Render
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)]

Build Command: npm install && cd client && npm install && npm run build && cd ..
Start Command: npm start
Health: /api/health

Env vars (all free tier):
- OPENROUTER_API_KEY - get free at openrouter.ai (free models: mistral-7b, llama-3-8b free)
- GITHUB_TOKEN - ghp_... (for repo cloning)
- RENDER_API_KEY - rnd_... (for auto-deploy)
- PAYSTACK_SECRET - sk_test_... (South Africa payments, use Paystack)
- SUPABASE_URL + SUPABASE_KEY - free Postgres (replace in-memory DB)

### Features Built

1. Dashboard - revenue pipeline, free-stack status
2. Intake+ - dynamic discovery questions per service
3. Builder Studio - Prompt-to-App: describe app -> GitHub repo -> Render live URL
4. Agent Forge - visual Trigger -> LLM -> Tool -> Action builder, exports LangChain JSON
5. Proposals - dynamic pricing base + complexity
6. Client Portal /c/:id - white-label, Paystack payment, live URL, deliverables
7. Delivery Factory - Kanban ToDo -> Building -> QA -> Delivered
8. Growth - Prompt Pack Marketplace + Retainer Automator

### Marketing Ready

Your landing copy (use in Tally form description + WhatsApp bio):

"ITG Factory: We build any AI system in 7 days.
You get: Private GitHub repo + Live URL on Render + Prompt library + Training + Client portal.
Track progress live. Pay with Paystack. Starting at R15,000.
WhatsApp us: 'BUILD'"

Your 3 packages to sell tomorrow:
- Starter R15k: Prompt Pack + Automation (Notion/Gmail)
- Growth R35k: WhatsApp Bot + CRM + Portal
- Factory R60k: Custom SaaS + LangChain Agent + Retainer

### How to market today

1. Deploy this app
2. Change white-label to your agency
3. Create Tally form that POSTs to /api/intake
4. Record 60s Loom walking through Client Portal
5. Post on LinkedIn + WhatsApp Status: "I built a factory that builds apps. Demo inside."

### Swap In-Memory to Supabase (when ready)

Replace db = {clients:[]} with Supabase client. Schema in /supabase/schema.sql

### Zapier Blueprint

Import zapier-blueprint.json: Tally -> Webhook POST /api/intake -> Gmail proposal -> Notion page -> Airtable

You are ready to sell. No more building.
